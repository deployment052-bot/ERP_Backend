import { DataTypes } from "sequelize";
import sequelize from "../config/db.js";

const Transaction = sequelize.define("Transaction", {
  transaction_date: DataTypes.DATE,
  transaction_type: DataTypes.STRING,
  organization_id: DataTypes.INTEGER,
});

export default Transaction;