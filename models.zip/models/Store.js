import { DataTypes } from "sequelize";
import sequelize from "../config/db.js";

const Store = sequelize.define("Store", {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  name: {
    type: DataTypes.STRING,
  },
  district_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
},
{
    tableName: "stores",
    freezeTableName: true,
     timestamps: false,
});

export default Store;