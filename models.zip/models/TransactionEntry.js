import { DataTypes } from "sequelize";
import sequelize from "../config/db.js";

const TransactionEntry = sequelize.define("TransactionEntry", {
  transaction_id: DataTypes.INTEGER,
  account_id: DataTypes.INTEGER,
  debit: DataTypes.FLOAT,
  credit: DataTypes.FLOAT,
});

export default TransactionEntry;