import { DataTypes } from "sequelize";
import sequelize from "../config/db.js";

const InvoiceItem = sequelize.define("InvoiceItem", {
  invoice_id: DataTypes.INTEGER,
  product_name: DataTypes.STRING,
  purity: DataTypes.STRING,
  weight: DataTypes.FLOAT,
  rate: DataTypes.FLOAT,
  making_charges: DataTypes.FLOAT,
  total: DataTypes.FLOAT,
});

export default InvoiceItem;