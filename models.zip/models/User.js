import { DataTypes } from "sequelize";
import sequelize from "../config/db.js";

/**
 * @description User Model
 * Maps camelCase fields (JS) to snake_case columns (PostgreSQL)
 */
const User = sequelize.define(
  "User",
  {
    /**
     * @description Primary Key - Store Code
     */
    storeCode: {
      type: DataTypes.STRING,
      primaryKey: true,
      allowNull: false,
      field: "store_code",
    },

    /**
     * @description User Email (Unique)
     */
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true,
      },
    },

    /**
     * @description Username
     */
    username: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },

    /**
     * @description Phone Number
     */
    phoneNumber: {
      type: DataTypes.STRING,
      unique: true,
      field: "phone_number",
    },

    /**
     * @description User Role (manager, admin, sales_girl)
     */
    role: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: "user",
    },

    /**
     * @description Police Verification Status
     */
    isPoliceVerified: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      field: "is_police_verified",
    },

    /**
     * @description Police Document URL
     */
    policeDocUrl: {
      type: DataTypes.STRING,
      field: "police_doc_url",
    },

    /**
     * @description Aadhaar Document URL
     */
    aadhaarUrl: {
      type: DataTypes.STRING,
      field: "aadhaar_url",
    },

    /**
     * @description PAN Document URL
     */
    panUrl: {
      type: DataTypes.STRING,
      field: "pan_url",
    },

    /**
     * @description Store Name
     */
    storeName: {
      type: DataTypes.STRING,
      field: "store_name",
    },

    /**
     * @description Organization Level (HEAD / DISTRICT / STORE)
     */
    organizationLevel: {
      type: DataTypes.STRING,
      field: "organization_level",
    },

    /**
     * @description User Password (Hashed)
     */
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },

    /**
     * @description Unique User Code
     */
    userCode: {
      type: DataTypes.STRING,
      unique: true,
      field: "user_code",
    },

    /**
     * @description Active Status
     */
    isActive: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
      field: "is_active",
    },
  },
  {
    /**
     * @description Table Configuration
     */
    tableName: "users",
    timestamps: false,
  }
);

export default User;